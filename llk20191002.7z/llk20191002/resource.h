//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� llk20191002.rc ʹ��
//
#define IDD_LLK20191002_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDC_BUTTON1                     1000
#define IDC_EDIT4                       1006
#define IDC_EDIT5                       1007
#define IDC_EDIT1                       1010
#define IDC_BUTTON2                     1011
#define IDC_BUTTON3                     1012
#define IDC_BUTTON4                     1013
#define IDC_BUTTON5                     1015
#define IDC_BUTTON6                     1017
#define IDC_EDIT7                       1019
#define IDC_BUTTON7                     1020
#define IDC_BUTTON8                     1021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
